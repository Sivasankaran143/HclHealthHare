﻿//using DinkToPdf;
//using DinkToPdf.Contracts;

//namespace Repository.PDF_Utility
//{
//    public class GenerateQuotationPdf
//    {
//        private readonly IConverter _converter;
//        public GenerateQuotationPdf(IConverter converter)
//        {
//            _converter = converter;
//        }

//        public async Task<byte[]> QuotationPDF()
//        {
//            var htmlContent = @"
//            <html>
//                <head>
//                    <style>
//                        body { font-family: Arial, sans-serif; margin: 20px; }
//                        .header { text-align: center; margin-bottom: 20px; }
//                        .header h1 { color: #007ACC; font-size: 24px; }
//                        .company-info, .customer-info { font-size: 14px; }
//                        .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
//                        .table th, .table td { border: 1px solid #ddd; padding: 8px; }
//                        .table th { background-color: #f2f2f2; text-align: left; }
//                        .total { text-align: right; font-weight: bold; }
//                    </style>
//                </head>
//                <body>
//                    <div class='header'>
//                        <h1>Quotation</h1>
//                        <p>Quotation Date: " + DateTime.Now.ToString("yyyy-MM-dd") + @"</p>
//                    </div>
//                    <div class='company-info'>
//                        <p><strong>Company Name:</strong> Sample Company</p>
//                        <p><strong>Address:</strong> 123 Street, City, State</p>
//                        <p><strong>Email:</strong> company@example.com</p>
//                    </div>
//                    <div class='customer-info'>
//                        <p><strong>Customer Name:</strong> John Doe</p>
//                        <p><strong>Address:</strong> 456 Avenue, City, State</p>
//                        <p><strong>Email:</strong> johndoe@example.com</p>
//                    </div>
//                    <table class='table'>
//                        <tr>
//                            <th>Item</th>
//                            <th>Quantity</th>
//                            <th>Unit Price</th>
//                            <th>Total</th>
//                        </tr>
//                        <tr>
//                            <td>Item 1</td>
//                            <td>2</td>
//                            <td>$50.00</td>
//                            <td>$100.00</td>
//                        </tr>
//                        <tr>
//                            <td>Item 2</td>
//                            <td>1</td>
//                            <td>$150.00</td>
//                            <td>$150.00</td>
//                        </tr>
//                        <tr>
//                            <td colspan='3' class='total'>Subtotal</td>
//                            <td>$250.00</td>
//                        </tr>
//                        <tr>
//                            <td colspan='3' class='total'>Tax (10%)</td>
//                            <td>$25.00</td>
//                        </tr>
//                        <tr>
//                            <td colspan='3' class='total'>Total</td>
//                            <td>$275.00</td>
//                        </tr>
//                    </table>
//                </body>
//            </html>";

//            var pdfDocument = new HtmlToPdfDocument
//            {
//                GlobalSettings = new GlobalSettings
//                {
//                    PaperSize = PaperKind.A4,
//                    Orientation = Orientation.Portrait,
//                },
//                Objects = {
//                new ObjectSettings
//                {
//                    HtmlContent = htmlContent,
//                    WebSettings = { DefaultEncoding = "utf-8" }
//                }
//            }
//            };

//            var pdfByte = _converter.Convert(pdfDocument);

//           return await Task.Run(() => pdfByte);

//        }
//    }
//}
