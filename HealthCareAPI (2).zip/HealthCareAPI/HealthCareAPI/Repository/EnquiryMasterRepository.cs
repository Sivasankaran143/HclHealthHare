﻿using Dapper;
using Entity;
using Infrastructure;
using Newtonsoft.Json;
using System.Data;
using YourNamespace.Models;

namespace Repository
{
    public class EnquiryMasterRepository : IEnquiryMaster
    {
        private readonly IDbConnection _dbConnection;
        public EnquiryMasterRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<ResponseCls> CreateEnquiryMaster(EnquiryMaster enquiryMaster)
        {
            ResponseCls responseCls = new ResponseCls();
            try
            {
                var Sp_Name = "USP_CreateEnquiryMaster";
                var param = new {
                    EnquiryMaster = JsonConvert.SerializeObject(enquiryMaster)
                };
                responseCls.ResponseData = await _dbConnection.QueryAsync(Sp_Name, param ,null,null,CommandType.StoredProcedure);
                responseCls.IsSuccess = true;
            }
            catch (Exception ex)
            {
                responseCls.StatusMessage = ex.Message;
            }
            return responseCls;
        }

        public async Task<ResponseCls> GetEnquiryMaster()
        {
            ResponseCls responseCls = new ResponseCls();
            try
            {
                var Sp_Name = "Usp_GetEnquiryDetails";
                responseCls.ResponseData = await _dbConnection.QueryAsync(Sp_Name, null, null, null, CommandType.StoredProcedure);
                responseCls.IsSuccess = true;
            }
            catch (Exception ex)
            {
                responseCls.StatusMessage = ex.Message;
            }
            return responseCls;
        }
    }
}
