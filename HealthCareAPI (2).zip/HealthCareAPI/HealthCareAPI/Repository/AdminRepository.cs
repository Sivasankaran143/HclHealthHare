﻿using Entity;
using Infrastructure;
using System.Data;
using Dapper;

namespace Repository
{
    public class AdminRepository : IAdmin
    {
        private readonly IDbConnection _dbConnection;
        public AdminRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<ResponseCls> GetCompanyInfo()
        {
            ResponseCls responseCls = new ResponseCls();
            try
            {
                var query = "SELECT * FROM [CompanyInfo]";
                responseCls.ResponseData = await _dbConnection.QueryAsync(query);
                responseCls.IsSuccess = true;
            }
            catch (Exception ex)
            {
                responseCls.StatusMessage = ex.Message;
            }
            return responseCls;
           
        }
    }
}
