﻿using Dapper;
using DNGPromoters.Models;
using Entity;
using Infrastructure;
using Newtonsoft.Json;
using System.Data;
using YourNamespace.Models;

namespace Repository
{
    public class EmployeeRepository : IEmployee
    {
        private readonly IDbConnection _dbConnection;
        public EmployeeRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<ResponseCls> GetUserDetails(int roleID)
        {
            ResponseCls responseCls = new ResponseCls();
            try
            {
                var Sp_Name = "Usp_GetUserDetails";
                var param = new
                {
                    RoleID = roleID
                };
                responseCls.ResponseData = await _dbConnection.QueryAsync(Sp_Name, param, null, null, CommandType.StoredProcedure);
                responseCls.IsSuccess = true;
            }
            catch (Exception ex)
            {
                responseCls.IsSuccess = false;
                responseCls.StatusMessage = ex.Message;
            }
            return responseCls;
        }

        public async Task<ResponseCls> GetRoleMaster()
        {
            ResponseCls responseCls = new ResponseCls();
            try
            {
                var Sp_Name = "Select * From [dbo].[RoleMaster] order by RoleName";
                responseCls.ResponseData = await _dbConnection.QueryAsync(Sp_Name, null, null, null, CommandType.Text);
                responseCls.IsSuccess = true;
            }
            catch (Exception ex)
            {
                responseCls.IsSuccess = false;
                responseCls.StatusMessage = ex.Message;
            }
            return responseCls;
        }

        public async Task<ResponseCls> CreateUserInfo(UserInfo userInfo)
        {
            ResponseCls responseCls = new ResponseCls();
            try
            {
                var Sp_Name = "USP_CreateUserInfo";
                var param = new
                {
                    UserInfo = JsonConvert.SerializeObject(userInfo)
                };
                responseCls.ResponseData = await _dbConnection.QueryAsync(Sp_Name, param, null, null, CommandType.StoredProcedure);
                responseCls.IsSuccess = true;
            }
            catch (Exception ex)
            {
                responseCls.StatusMessage = ex.Message;
            }
            return responseCls;
        }


    }
}
