﻿using Dapper;
//using DinkToPdf.Contracts;
using Entity;
using Infrastructure;
//using Repository.PDF_Utility;
using System;
using System.Data;

namespace Repository
{
    public class QuotationRepository : IQuotation
    {
        private readonly IDbConnection _dbConnection;
       // private readonly IConverter _converter;
        public QuotationRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
            //_converter = converter;
        }

        public async Task<ResponseCls> GetProductDetails()
        {
            ResponseCls responseCls = new ResponseCls();
            try
            {
                var Sp_Name = "usp_getProductMaster";
                responseCls.ResponseData = await _dbConnection.QueryAsync(Sp_Name, null, null, null, CommandType.StoredProcedure);
                responseCls.IsSuccess = true;
            }
            catch (Exception ex)
            {
                responseCls.IsSuccess = false;
                responseCls.StatusMessage = ex.Message;
            }
            return responseCls;
        }

        public async Task<ResponseCls> GetQuotationDetails()
        {
            ResponseCls responseCls = new ResponseCls();
            try
            {
                var Sp_Name = "Usp_GetQuotationDetails";
                responseCls.ResponseData = await _dbConnection.QueryAsync(Sp_Name, null, null, null, CommandType.StoredProcedure);
                responseCls.IsSuccess = true;
            }
            catch (Exception ex)
            {
                responseCls.IsSuccess = false;
                responseCls.StatusMessage = ex.Message;
            }
            return responseCls;
        }

        //public async Task<ResponseCls> GeneratePdf(int QuotationID)
        //{
        //    ResponseCls responseCls = new ResponseCls();
        //    try
        //    {
        //        //GenerateQuotationPdf generateQuotationPdf = new GenerateQuotationPdf(_converter);
        //        //responseCls.PDFFile = await generateQuotationPdf.QuotationPDF();
        //        responseCls.IsSuccess = true;
        //    }
        //    catch(Exception ex)
        //    {
        //        responseCls.IsSuccess = false;
        //        responseCls.StatusMessage = ex.Message;
        //    }
        //    return  responseCls;
        //}
    }
}
