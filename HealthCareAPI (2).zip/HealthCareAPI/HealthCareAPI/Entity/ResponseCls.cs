﻿namespace Entity
{
    public class ResponseCls
    {
        public bool IsSuccess { get; set; }
        public object? ResponseData { get; set; }
        public string? StatusMessage { get; set; }
    }
}
