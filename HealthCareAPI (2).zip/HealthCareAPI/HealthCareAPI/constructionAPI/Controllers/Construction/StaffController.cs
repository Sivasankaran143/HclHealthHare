﻿
using Entity;
using Infrastructure.Construction;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthCareAPI.Controllers.Construction
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly IStaff _IStaff;
        public StaffController(IStaff IStaff) 
        {
            _IStaff=IStaff;
        }
        [HttpGet("GetStaffDetails")]
        public async Task<IActionResult> GetStaffDetails()
        {
            var item = await _IStaff.GetStaffDetails();
            return Ok(item);
        }

        [HttpPost("CreateStaffInfo")]
        public async Task<IActionResult> CreateStaffInfo(Staff userInfo)
        {
            var item = await _IStaff.AddStaffDetails(userInfo);
            return Ok(item);
        }
    }
}
