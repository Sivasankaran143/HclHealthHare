//using DinkToPdf.Contracts;
//using DinkToPdf;
using Infrastructure.Construction;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using Repository;
using System.Data;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Load configuration
builder.Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);



// Register services in the container
builder.Services.AddCors();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


builder.Services.AddTransient<IDbConnection>(db =>
    new SqlConnection(builder.Configuration.GetConnectionString("DefaultConnection")));


builder.Services.AddTransient<IStaff, StaffRepository>();
var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Apply CORS policy before authorization
app.UseCors(policy => policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());

app.UseAuthentication(); // Ensures authentication middleware is executed
app.UseAuthorization();  // Ensures authorization policies are executed

app.MapControllers();

app.Run();
